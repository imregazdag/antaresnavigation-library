//
//  AntaresNavigation.h
//  AntaresNavigation
//
//  Created by Gazdag Imre on 2017. 11. 14..
//  Copyright © 2017. Gazdag Imre. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for AntaresNavigation.
FOUNDATION_EXPORT double AntaresNavigationVersionNumber;

//! Project version string for AntaresNavigation.
FOUNDATION_EXPORT const unsigned char AntaresNavigationVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AntaresNavigation/PublicHeader.h>


